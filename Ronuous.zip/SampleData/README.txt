# Demo Content (.xml file)

You can importing content data in our theme using Demo Data XML. After the 
Installation of the theme, navigate  Tool > Import, click on "WordPress". 
You may asked to install "Importer" plugin. Select the .xml file that 
you can find in this folder. If you want to import the demo content for 
plugins (WooCommerce, Contactform 7,...), make sure to install them 
before running the Importer!

After your content is imported you need to set up the Menus. 
Go to Appearance > Menus and click the "Manage Locations" button at the top. 
Select a Menu for the "Primary Navigation" and save it.


# Widget Content (.wie file)

To importing the sample widgets, you can use the 'Widget Importer & 
Exporter' plugin (available on wordpress plugin repository). 
Once install the plugin go to Tools > Widget Import/Export and uploading 
the export file(.wie). The results are shown in a nicely formatted table 
with an explanation of what happened with each sidebar and widget.