# Installing Plugins
------------------------------------------------------------------------

After Theme installation you should see a notice asking you to install
all the required & recommended plugins for this theme. Just follow the 
instructions to install plugins.

If you don't see any notices, you can find them in this folder for 
manual installation.