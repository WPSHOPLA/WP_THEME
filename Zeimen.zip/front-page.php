<main class="front-main" role="main">
	<?php while (have_posts()) : the_post(); ?>
	  <?php get_template_part('templates/header', 'front'); ?>
	  <?php get_template_part('templates/content', 'front'); ?>
	<?php endwhile; ?>
</main>
