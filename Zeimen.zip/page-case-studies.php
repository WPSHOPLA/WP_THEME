<?php
/*
Template Name: Case Studies Template
*/
$paged = 1;
if ( get_query_var('paged') ) $paged = get_query_var('paged');
if ( get_query_var('page') ) $paged = get_query_var('page');
?>

      
      <div class="container container-1000">
        <main class="inner-content">
          <div class="page-header i-page-header">
           <?php
              if (have_posts()) :
                while (have_posts()) : the_post();
                  echo '<h1 class="page-title">'.get_the_title().'</h1>';
                endwhile;
            endif;
            ?> 
            
          </div>
          <div class="case-studies-wrap">
            <?php 
            $i = 2;
            $args = array('post_type' => 'caseStudy', 'order' => 'asc', 'orderby' => 'menu_order', 'posts_per_page' => 4,  'paged' => $paged);
             $wp_query = new WP_Query( $args );


             if ( $wp_query->have_posts() ):
              while ( $wp_query->have_posts() ): $wp_query->the_post(); 
                if ($i%2==0) {
                  echo '<div class="row row-case">';
                }
                echo '<div class="col-sm-6"><div class="case-studies-box">';
                echo '<h4 class="case-ttl">'.get_the_title().'</h4>';
                echo '<ul class="case-list">';
                if ( has_post_thumbnail() ) {
                  echo '<figure class="case-preview img-responsive-container"><a href="'.get_the_permalink().'">';
                  the_post_thumbnail();    
                  echo '</a></figure>';                
                }
                echo '<li><span class="i-label i-label-green">'.get_field('NumberOfConversions',$post->ID).'</span>Number of Conversions Improvement</li>';
                echo '<li><span class="i-label i-label-yellow">'.get_field('CostOfConversions',$post->ID).'</span>Cost of Conversions Improvement</li>';
                echo '</ul>';
                echo '<div class="case-dec"><p>'.get_field('caseShortText',$post->ID).'</p></div>';
                echo '<a href="'.get_the_permalink().'" class="btn-main">See Full Study</a>';
                echo '</div></div>';
                if ($i%2!=0) {
                  echo '</div>';
                }
                $i++;
              endwhile;
              endif;
            wp_reset_postdata();
             ?>
          </div>
          <div class="i-pagination">
            <?php next_posts_link('Next Page') ?>
            <?php previous_posts_link('Previous Page') ?>
            <!-- <a href="#" class="color-blue">Next Page</a> -->
          </div>

        </main>
        
      </div>
    