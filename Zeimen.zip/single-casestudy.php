     
      <div class="single-cs">
      <?php
        if (have_posts()) :
          while (have_posts()) : the_post(); ?>
            
     
        <div class="cs-title">
          <div class="container">
            <strong class="logo-cs icon">Guaranteed PPC</strong>
            <h1>PPC Management Case Study</h1>
          </div>
        </div>
        <div class="row-cs head-cs dark">
          <div class="container">
            <div class="row">
              <div class="col-sm-6">
                <div class="head-left-cs">
                  <h4> <?php the_field('CaseTypeSubtitle',$post->ID); ?> </h4>
                  <h2>
                  <?php the_title(); ?>
                   <em> <?php the_field('CaseType',$post->ID); ?> </em></h2>
                  <ul class="case-list">
                    <li><span class="i-label i-label-green"><?php the_field('NumberOfConversions',$post->ID) ?></span>Number of Conversions Improvement</li>
                    <li><span class="i-label i-label-yellow"><?php the_field('CostOfConversions',$post->ID); ?></span>Cost of Conversions Improvement</li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-6">
                <figure class="img-responsive-container">
                  <?php if ( has_post_thumbnail() ) {
                    the_post_thumbnail();                    
                  } ?>
                </figure>
              </div>
            </div>
          </div>
        </div>
        
       
        <?php the_content(); ?>
         <?php endwhile;
      endif;
      ?>
      </div>
    