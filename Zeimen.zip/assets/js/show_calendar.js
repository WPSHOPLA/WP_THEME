var calendar1= '<iframe style="display:none;" id="calendar_frame" src="http://www.vcita.com/widgets/scheduler/gnbtd4h58i12c9io?ver=2" \
  width="500" height="450" scrolling="no" frameborder="0" style=" "> \
  &lt;p&gt;Use my online scheduling page by vCita to schedule an appointment with me:&lt;/p&gt; \
  &lt;a href="http://www.vcita.com/v/gnbtd4h58i12c9io/online_scheduling?invite=vr_sched_pb-gnbtd4h58i12c9io"&gt;\
  Online Scheduling with Guaranteed PPC&lt;/a&gt;</iframe>';

var calendar= '<iframe style="display:none;" id="calendar_frame" src="http://www.vcita.com/v/gnbtd4h58i12c9io/online_scheduling?o=bGl2ZXNpdGVfYWN0aXZlX2VuZ2FnZQ%3D%3D&prevent_redirect=true" \
  width="800" height="600" scrolling="no" frameborder="0" style=" "> \
  &lt;p&gt;Use my online scheduling page by vCita to schedule an appointment with me:&lt;/p&gt; \
  &lt;a href="http://www.vcita.com/v/gnbtd4h58i12c9io/online_scheduling?invite=vr_sched_pb-gnbtd4h58i12c9io"&gt;\
  Online Scheduling with Guaranteed PPC&lt;/a&gt;</iframe>';

var calendar_trigger = '<a id="calhref" href="#calendar_frame" class="fancybox"></a>';

$("body").append(calendar_trigger);
$("body").append(calendar);

$("#calhref").fancybox({
	maxWidth		: 800,
	maxHeight		: 600,
	fitToView		: false,
	width			: '70%',
	height 			: '70%',
	autosize		: true,
	openEffect		: 'none',
	closeEffect		: 'none',
	scrolling		: 'auto',
	helpers       	: {
    	overlay : {
            	css : {
                	'background' : 'rgba(58, 42, 45, 0.3)'
            	}
        	}
    	}
	});

$.fancybox.helpers.overlay.open({parent:$('body')});
$("#calhref").trigger('click');	
