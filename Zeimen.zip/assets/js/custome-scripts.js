jQuery(document).ready(function($) {

	var responsive_viewport = jQuery(window).width();
	var fixElement = jQuery('.single .sidebar .inner-sidebar, .blog .sidebar .inner-sidebar');
	$( window ).resize(function() {
		fixElement.width(fixElement.closest('.sidebar').width())
	})
	if(fixElement.size()>0){
		var pos = fixElement.offset().top-150;
			if (responsive_viewport > 1000 && $('.wrap').height()>$('.sidebar').height()) {
				jQuery(window).on('scroll resize',function(){
				 var Top = jQuery(document).scrollTop();
				 if(Top > pos){
				 	fixElement.addClass('fixed');	
				 	fixElement.width(fixElement.closest('.sidebar').width())				 	
				 }
				 else{
					fixElement.removeClass('fixed');
				 }
				});
			}
	}
	if($('body').hasClass('blog')||$('body').hasClass('single-post')) {
		setTimeout(function() {
			$('#myModal').modal('show');
		}, 60000)			
	}


	$("p.call-to-action a").bind('click.smoothscroll', function(e){
		e.preventDefault();
		var target = this.hash, $target = $(target);

		$('html, body').stop().animate({
			scrollTop: $("#call-to-action-target").offset().top - 100
		}, 3000, 'swing', function() {window.location.hash = target});
	});

});

$('.fancybox').fancybox({
	padding: 0,
	fitToView: false,
	wrapCSS: 'fancylanding',
	maxWidth: 940,
	width: 'auto',
	 helpers : {
        overlay : {
            css : {
                'background' : 'rgba(58, 42, 45, 0.3)'
            }
        }
    }
	
});
// var $lightbox = $('#lightbox');
    
//     $('[data-target="#lightbox"]').on('click', function(event) {
//         var $src = $(this).attr('href');
//     		console.log($src)
//         $lightbox.find('.modal-close').addClass('hidden');
//         //$lightbox.find('img').attr('src', $src);
//         //$lightbox.find('img').css(css);
//     });
    
//     $lightbox.on('shown.bs.modal', function (e) {
//         var $img = $lightbox.find('img');
            
//         //$lightbox.find('.modal-dialog').css({'width': $img.width()});
//         $lightbox.find('.modal-close').removeClass('hidden');
//     });


var inFormOrLink;
$('a').on('click', function() { inFormOrLink = true; });
$('form').on('submit', function() { inFormOrLink = true; });

// $(window).on("beforeunload", function() { 
// 	if(!inFormOrLink) {
// 		$('#myModal').modal('show');
//     return "Do you really want to close?"; 
// 	}
// })
var isTopModalShow = false;

$(window).on('mouseleave', function(e){
	var pos = e.pageY - $(window).scrollTop();
	$('#position').text(e.pageY);
	if(pos<=1&&isTopModalShow ==false) {
		$('#myModal').modal('show');
		isTopModalShow = true;
	}
})


/*$("p.call-to-action a").click(function(e){
	e.preventDefault();
	$('html, body').animate({
		scrollTop: $("#call-to-action-target").offset().top
	}, 2000);
});*/

