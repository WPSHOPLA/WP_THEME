<?php
/*
Template Name: Custom Template
*/
?>

<div class="container">
	<main class="main" role="main">
		<?php while (have_posts()) : the_post(); ?>
		  <?php get_template_part('templates/page', 'header'); ?>
		  <?php get_template_part('templates/content', 'page'); ?>
		<?php endwhile; ?>
	</main>

	<?php if (roots_display_sidebar()) : ?>
	  <aside class="sidebar" role="complementary">
	    <?php include roots_sidebar_path(); ?>
	  </aside><!-- /.sidebar -->
	<?php endif; ?>
</div>