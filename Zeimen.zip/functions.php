<?php
/**
 * Roots includes
 *
 * The $roots_includes array determines the code library included in your theme.
 * Add or remove files to the array as needed. Supports child theme overrides.
 *
 * Please note that missing files will produce a fatal error.
 *
 * @link https://github.com/roots/roots/pull/1042
 */
$roots_includes = array(
  'lib/utils.php',           // Utility functions
  'lib/init.php',            // Initial theme setup and constants
  'lib/wrapper.php',         // Theme wrapper class
  'lib/sidebar.php',         // Sidebar class
  'lib/config.php',          // Configuration
  'lib/activation.php',      // Theme activation
  'lib/titles.php',          // Page titles
  'lib/nav.php',             // Custom nav modifications
  'lib/gallery.php',         // Custom [gallery] modifications
  'lib/scripts.php',         // Scripts and stylesheets
  'lib/extras.php',          // Custom functions
);

foreach ($roots_includes as $file) {
  if (!$filepath = locate_template($file)) {
    trigger_error(sprintf(__('Error locating %s for inclusion', 'roots'), $file), E_USER_ERROR);
  }

  require_once $filepath;
}
unset($file, $filepath);

function remove_author_pages_page() {
  if ( is_author() ) {
    wp_safe_redirect( home_url('/'), '301' );
    exit;
    /*global $wp_query;
    $wp_query->set_404();
    status_header( 404 );
    safe_redirect();*/
  }
}

function remove_author_pages_link( $content ) {
  return esc_url( home_url( '/' ) );
}


function show_calendar_after_submit(){
  echo '<script type="text/javascript"></script>';
}

function add_footer_show_calendar_after_submit($contact_form)
{
  add_action('wp_footer', 'show_calendar_after_submit');

  wp_enqueue_style('fancybox-style', get_template_directory_uri() . '/assets/js/fancybox/jquery.fancybox.css', false, null);

  $embed_url1= get_template_directory_uri() . '/assets/js/fancybox/jquery.fancybox.pack.js';
  wp_register_script('fancybox', $embed_url1, array('jquery'), FALSE, TRUE);
  wp_enqueue_script('fancybox');

  $embed_url2= get_template_directory_uri() . '/assets/js/show_calendar.js';
  wp_register_script('show_calendar', $embed_url2, array('jquery'), FALSE, TRUE);
  wp_enqueue_script('show_calendar');
}

add_action( 'template_redirect', 'remove_author_pages_page' );
add_filter( 'author_link', 'remove_author_pages_link' );
add_action( 'wpcf7_mail_sent', 'add_footer_show_calendar_after_submit' );

@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );


