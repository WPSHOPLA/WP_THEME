### 1.0.0 December 11, 2014

* Switched from Roots.io to Zeimen Theme
* Added custom screenshot