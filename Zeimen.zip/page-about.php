<?php
/*
Template Name: About Page Template
*/
?>
<div>
  <main class="main" role="main">
    <div class="container wide-container">
        <main class="page-content page-about" role="main">
          <section class="about-top-section">
          
            <div class="images-about">
              <?php $img = get_field('about_photo_main',$post->ID); ?>
              <img class="main-img img-responsive" src="<?php echo $img['url'] ?>" alt="" >

              <ul>
                <li>
                <?php $img = get_field('about_1',$post->ID); ?>
                <img class="img-responsive" src="<?php echo $img['url'] ?>" alt="" ></li>
                <li>
                <?php $img = get_field('about_2',$post->ID); ?>
                <img class="img-responsive" src="<?php echo $img['url'] ?>" alt="" ></li>
                <li>
                <?php $img = get_field('about_3',$post->ID); ?>
                <img class="img-responsive" src="<?php echo $img['url'] ?>" alt="" ></li>
              </ul>
            </div>

            <div class="about-wrap">
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                  
                  
                
              <h1><?php the_title(); ?></h1>
              <!-- <p>Guaranteed PPC is a full service, direct response marketing agency specializing in pairing great PPC advertising strategy with high converting PPC landing pages to generate predictable lead flow for their clients worldwide.</p>
              <p>Whether you want us to leverage a house list with PPC or craft the perfect sales funnel to generate new customers from scratch, Guaranteed PPC has you covered.</p>
              <p>Offering lead flow from Google AdWords, Facebook Ads, Twitter Ads, LinkedIn Ads, YouTube Ads, Bing Ads, and more.</p> -->
              <?php the_content(); ?>

              <?php endwhile;?>
                <?php endif; ?>
            </div>
          </section>
          <div class="team-area">          
          <?php
            $args = array('post_type' => 'employee', 'order' => 'asc', 'orderby' => 'menu_order', 'posts_per_page' => -1);
             $query = new WP_Query( $args );
             if ( $query->have_posts() ):
              while ( $query->have_posts() ): $query->the_post(); ?>
              <section class="team-block">
                <div class="team-cell">
                  <?php if ( has_post_thumbnail() ) { ?>
                     <figure>
                      <?php the_post_thumbnail(); ?>
                    
                    </figure>
                  <?php }  ?>                 
                  <h2><?php the_title(); ?></h2>                  
                  <h5><?php the_field('role',$post->ID) ?></h5>
                </div>
                <article class="team-text">
                  <?php the_content(); ?>
                </article>
              </section>
              
              
            <?php endwhile;
              endif;
            wp_reset_postdata();
             ?>
          </div>
        </main>
        
      </div>

        <div class="about-clients" id="clients">
          <div class="container">
            <h3>Our Clients</h3>
          <?php 
            if( have_rows('client_logos') ):
            echo '<ul class="about-clients-list">';
             while ( have_rows('client_logos') ) : the_row();
                
                $img = get_sub_field('client_logo',$post->ID);
                echo '<li><span class="v-table"><span class="v-cell"><img class="img-responsive" src="'.$img['url'].'" alt="" > </span></span></li>';

            endwhile;
            echo '</ul>';
           endif;
          ?>
            
          </div>
        </div>

  </main>

</div>