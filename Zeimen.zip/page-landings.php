<?php
/*
Template Name: Landing Pages Template
*/
?>
<script>
  

</script>
<div class="page-landing">
	<main class="wrap">
		<div class="container">
      <main >
        <?php
          if (have_posts()) :
            while (have_posts()) : the_post(); ?>
            <div class="page-header">
              <h1 class="page-title"><?php the_title(); ?></h1>
            </div>
            <?php the_content(); ?>
            <?php endwhile;
        endif;
        ?>
          
          <div class="landing-wrap">
          <?php if( have_rows('landings_group') ):
            echo '<div class="row row-landing">';
            while ( have_rows('landings_group') ) : the_row();
            $img = get_sub_field('landing_image',$post->ID);
            $imgModal = get_sub_field('landing_image_modal',$post->ID);

             ?>
            
              <div class="col-sm-6">
                <div class="landing-box">
                  <a href="<?php echo $imgModal['url']; ?>" class="btn-enlarge fancybox"><i></i></a>
                  <a href="<?php echo $imgModal['url']; ?>" class="fancybox"><img class="img-responsive" src="<?php echo $img['url']; ?>" alt="" ></a>
                </div>
              </div>
            <?php
              endwhile;
             endif;
            ?>

            <div class="col-sm-6">
                <div class="landing-box">
                  <div class="landing-box-text">
                    <div class="v-center">
                      <h4>Guaranteed PPC Management &amp; Landing Page Optimization</h4>
                      <h5> Get measurable results in 60 days, or I’ll pay you $500 instead!</h5>
                      <a href="http://guaranteedppc.com/#wpcf7-f30-p5-o2" class="btn-contact">Contact Us Today</a>
                    </div>
                  </div>
                </div>
              </div>
</div>
            <?php
          
             
                
                

            
          
           ?> 
          </div>
        </main>
    </div>
	</main>

</div>
<script>
    jQuery(document).ready(function($) {
      alert('fss');

    });
    </script>