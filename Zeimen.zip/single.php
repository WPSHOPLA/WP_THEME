<!-- <div class="splash">
		<?php if (has_post_thumbnail()) {
	the_post_thumbnail();
} else {?>
<img class="img-responsive" src="<?php echo get_stylesheet_directory_uri();?>/images/splash.jpg" alt="">
<?php }
?>

  </div> -->
<?php
$currentId = get_the_ID();
$feat_image = wp_get_attachment_url(get_post_thumbnail_id($currentId));
if ($feat_image) {
	$bg = $feat_image;
} else {
	$bg = get_stylesheet_directory_uri() . '/assets/img/bg-splash.jpg';
}
$author = get_field('author', $currentId);
$difficulty = get_field('difficulty', $currentId);
?>

<div class="splash-banner" style="background: url('<?php echo $bg;?>') no-repeat 50% 0;">
  <div class="container">

    <h1 class="entry-title"><?php echo get_the_title($currentId);?></h1>
    <div class="splash-bottom">
      <div class="difficulty-box">
        <span>Difficulty: <strong><?php echo $difficulty;?>/10</strong> </span>
        <span class="diff-stripe"><i class="selector sel-<?php echo $difficulty;?>"></i></span>
        <!-- <span class="diff-stripe"><i class="selector sel-2"></i></span>
        <span class="diff-stripe"><i class="selector sel-3"></i></span>
        <span class="diff-stripe"><i class="selector sel-4"></i></span>
        <span class="diff-stripe"><i class="selector sel-5"></i></span>
        <span class="diff-stripe"><i class="selector sel-6"></i></span>
        <span class="diff-stripe"><i class="selector sel-7"></i></span>
        <span class="diff-stripe"><i class="selector sel-8"></i></span>
        <span class="diff-stripe"><i class="selector sel-9"></i></span>
        <span class="diff-stripe"><i class="selector sel-10"></i></span> -->
      </div>
      <span class="author"><?php echo $author;?></span>
    </div>
  </div>
</div>
<div class="container wide-container">
	<main class="main" role="main">
		<?php get_template_part('templates/content', 'single');?>


		<?php get_template_part('templates/ad', 'single');?>

	</main>

	<?php if (roots_display_sidebar()): ?>
	  <aside class="sidebar" role="complementary">
	    <div class="inner-sidebar"><?php include roots_sidebar_path();?></div></div>
	  </aside><!-- /.sidebar -->
	<?php endif;?>
</div>

<?php
  $ppc_label = get_field("post_contact_label", $currentId);
  $label_size = get_field("contact_label_size", $currentId);
  $label_color = get_field("contact_label_color", $currentId);

  $session_label = get_field("post_contact_session_label", $currentId);
  $submit_button = get_field("post_contact_submit_button", $currentId);
  $waiting = get_field("post_contact_waiting", $currentId);

  if($ppc_label){
    echo '<script>$("blockquote.quotes p").html("'.$ppc_label.'").css({"color": "'.$label_color.'", "font-size": "'.$label_size.'px"})</script>';
  }

  if ($session_label)
    echo '<script>$("#contact_label").html("'.$session_label.'");</script>';
  if ($submit_button)  
  {
    echo '<script>$("#contact_submit").attr("value", "'.$submit_button.'");</script>';
   }
  if ($waiting)  
    echo '<script>$("#contact_waiting").html("'.$waiting.'");</script>';
?>
