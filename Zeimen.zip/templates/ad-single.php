<?php

// Get Values from ACF 
$pageHomeId = 5;
$photo      = get_field('photo', $pageHomeId);
$name       = get_field('name', $pageHomeId);
$jobTitle   = get_field('job_title', $pageHomeId);
$slogan     = get_field('slogan', $pageHomeId);
$hf_form    = get_field('header_form', $pageHomeId);

?>
<div class="post-bottom">
  <div class="post-form" id = "call-to-action-target">
    <header class="head">
      <div class="about-cell">
        <span class="sub-title">Author:</span>
        <h3><?php echo $name; ?></h3>
        <span class="role"><?php echo $jobTitle; ?></span>
      </div>
      <div class="head-container">
        <figure class="preview-img">
          <img class="img-responsive" src="<?php echo $photo['url']; ?>" alt="">
        </figure>
        <blockquote class="quotes">
          <?php echo $slogan; ?>                       
        </blockquote>
      </div>
    </header>
    <div class="optin-form">
    <?php echo do_shortcode( $hf_form ); ?>
    </div>
  </div>
</div>
<?php
  comments_template('/templates/comments.php');
?>
