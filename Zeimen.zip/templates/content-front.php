<?php 

// Get Values from ACF 
$hiw_intro 			= get_field('hiw_intro');
$headline_title	= get_field('hiw_headline_title');

?>
<div id="how-it-work">
	<div class="container">
		<div class="feature-list">
			<h2><?php echo $hiw_intro; ?></h2>
			<div class="row feature-list">
				<div class="col-xs-3 col-sm-6 text-right">
					<i class="spr bubble-icon"></i>
				</div>
				<div class="col-xs-9 col-sm-6">
					<?php if(get_field('hiw_feature_list')) {
						echo '<ul class="custom-list">';

						// loop_start
						while(the_repeater_field('hiw_feature_list')) :
							echo '<li>'.get_sub_field('feature_item').'</li>';
						endwhile;

						echo '</ul>';
					} ?>
				</div>
			</div>
		</div>
		
	</div>
	<div class="container">
		<header class="section-header">
			<h1><?php echo $headline_title; ?></h1>
		</header>
	</div>

	<?php

	// check if the flexible content field has rows of data
	if( have_rows('how_it_work_row') ):
	 	// loop through the rows of data
	    while ( have_rows('how_it_work_row') ) : the_row();
			// check current row layout
				if( get_row_layout() == 'two_column' ):
        	// check if the nested repeater field has rows of data

        	$class = get_sub_field('row_class');

        	echo '<div class="hiw-item '.$class.'"><div class="container"><div class="row">';
        
      		if( have_rows('first_column') ):
				 		echo '<div class="col-sm-5">';

				 		while ( have_rows('first_column') ): the_row();

				 		if( get_row_layout() == 'large_text' ):
				 			$text = get_sub_field('large_text');
				 			echo '<p class="text-lg">'.$text.'</p>';

		        elseif( get_row_layout() == 'small_text' ):
		        	$text = get_sub_field('small_text');
				 			echo '<p class="text-md">'.$text.'</p>';

		        elseif( get_row_layout() == 'simple_image' ):
		        	$image = get_sub_field('image');
		        	echo '<img src="'.$image['url'].'" class="img-responsive" alt="'.$image['alt'].'">';

		        elseif( get_row_layout() == 'responsive_image' ):
		        	$image1 = get_sub_field('desktop_image');
		        	$image2 = get_sub_field('mobile_image');
		        	echo '<img src="'.$image1['url'].'" class="img-responsive hidden-xs" alt="'.$image1['alt'].'">';
		        	echo '<img src="'.$image2['url'].'" class="img-responsive visible-xs" alt="'.$image2['alt'].'">';
		        endif;

				 		endwhile;

						echo '</div>';

					endif;

					if( have_rows('second_column') ):
				 		echo '<i class="arrow-right spr"></i>
				<div class="col-sm-5 col-sm-offset-2">';

				 		while ( have_rows('second_column') ): the_row();

				 		if( get_row_layout() == 'large_text' ):
				 			$text = get_sub_field('large_text');
				 			echo '<p class="text-lg">'.$text.'</p>';

		        elseif( get_row_layout() == 'small_text' ):
		        	$text = get_sub_field('small_text');
				 			echo '<p class="text-md">'.$text.'</p>';

		        elseif( get_row_layout() == 'simple_image' ):
		        	$image = get_sub_field('image');
		        	echo '<img src="'.$image['url'].'" class="img-responsive" alt="'.$image['alt'].'">';

		        elseif( get_row_layout() == 'responsive_image' ):
		        	$image1 = get_sub_field('desktop_image');
		        	$image2 = get_sub_field('mobile_image');
		        	echo '<img src="'.$image1['url'].'" class="img-responsive hidden-xs" alt="'.$image1['alt'].'">';
		        	echo '<img src="'.$image2['url'].'" class="img-responsive visible-xs" alt="'.$image2['alt'].'">';
		        endif;

				 		endwhile;

						echo '</div>';

					endif;

					echo '</div></div></div>';



	      elseif( get_row_layout() == 'one_column' ):
        	// check if the nested repeater field has rows of data
        	$class = get_sub_field('row_class');

        	echo '<div class="hiw-item '.$class.'"><div class="container"><div class="row">';

        	if( have_rows('column_item') ):
				 		echo '<div class="col-sm-12">';

				 		while ( have_rows('column_item') ): the_row();

				 		if( get_row_layout() == 'large_text' ):
				 			$text = get_sub_field('large_text');
				 			echo '<p class="text-lg">'.$text.'</p>';

		        elseif( get_row_layout() == 'small_text' ):
		        	$text = get_sub_field('small_text');
				 			echo '<p class="text-md">'.$text.'</p>';

		        elseif( get_row_layout() == 'simple_image' ):
		        	$image = get_sub_field('image');
		        	echo '<img src="'.$image['url'].'" class="img-responsive" alt="'.$image['alt'].'">';

		        elseif( get_row_layout() == 'responsive_image' ):
		        	$image1 = get_sub_field('desktop_image');
		        	$image2 = get_sub_field('mobile_image');
		        	echo '<img src="'.$image1['url'].'" class="img-responsive hidden-xs" alt="'.$image1['alt'].'">';
		        	echo '<img src="'.$image2['url'].'" class="img-responsive visible-xs" alt="'.$image2['alt'].'">';
		        endif;

				 		endwhile;

						echo '</div>';

					endif;

					echo '</div></div></div>';

	      endif;

	    endwhile; //how_it_work_row


	else :

	    // no layouts found

	endif;

	?>

</div>

<?php
// Get Values from ACF 
$intro 			= get_field('whm_headline_title');
$text 			= get_field('whm_text');

?>
<div id="why-hire-me">
	<div class="container">
		<header class="section-header">
			<h1><?php echo $intro; ?></h1>
		</header>
		<div class="row">
			<div class="col-sm-3">
				<i class="spr bubble-icon"></i>
			</div>
			<div class="col-sm-9">
				<?php echo $text; ?>
			</div>
		</div>
	</div>
</div>
<div id="testimonials">
	<div class="container">
		<header class="section-header">
			<h1>Satisfied Clients</h1>
		</header>
		<?php
		// The Query
		$args = array(
			'post_type'				=> 'cz_testimonials',
			'posts_per_page'	=> 3
		);
		$the_query = new WP_Query( $args );

		// The Loop
		if ( $the_query->have_posts() ) {
			echo '<div class="row">';
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				$photo = get_field('photo');
				$name 	= get_field('name');
				$company = get_field('company');
				$testimonial 	= get_field('testimonial');
				?>
				<div class="col-sm-4">
					<div class="testimonial-item">
						<img src="<?php echo $photo['url']; ?>" class="avatar" alt="<?php echo $photo['alt']; ?>">
						<blockquote>
							<p><?php echo $testimonial; ?></p>
							<footer><span class="fn"><?php echo $name; ?></span>, <?php echo $company; ?></footer>
						</blockquote>
					</div>
				</div>
				
			<?php }
			echo '</div>';
		} else {
			// no posts found
		}
		/* Restore original Post Data */
		wp_reset_postdata();
		?>
	</div>
</div>

<?php 
// Get Values from ACF 
$bf_intro 		= get_field('bf_form_intro');
$bf_desc			= get_field('bf_form_description');
$bf_form 			= get_field('bf_form');
?>
<div id="waiting-list">
	<div class="container">
		<div class="waiting-list-intro">
			<h3><?php echo $bf_intro; ?></h3>

			<?php if(get_field('bf_feat_list')) {
				echo '<ul class="custom-list">';

				// loop_start
				while(the_repeater_field('bf_feat_list')) :
					echo '<li>'.get_sub_field('feature_item').'</li>';
				endwhile;

				echo '</ul>';
			} ?>
		</div>
		<div class="row">
			<div class="col-sm-4 text-right">
				<i class="spr bubble-icon"></i>
			</div>
			<div class="col-sm-8">
				<p><em><?php echo $bf_desc; ?></em></p>
			</div>
		</div>
		<div class="optin-form">
			<?php echo do_shortcode( $bf_form ); ?>
		</div>
	</div>
</div>
