<footer class="content-info" role="contentinfo">
  <div class="container clearfix">
    <?php dynamic_sidebar('sidebar-footer'); ?>
    <!-- <div class="row">
    	<div class="col-sm-6">
    		<p>© 2016 Guaranteed PPC | 1335 Broadway Denison, IA</p>
    	</div>
    	<div class="col-sm-6">
    		Privacy Policy | Terms Of Service | Tel: 1-712-579-4553
    	</div>
    </div> -->
  </div>
</footer>
<!-- lighbox modal -->
<div class="new-modal modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Guaranteed Revenue Boost</h4>
        </div>
        <div class="modal-body">
          <div class="modal-form-wrap">
            <div class="text-wrap">
              <ul class="list">
                <li>Unsure about who to hire to revise your PPC campaign and landing page strategy?</li>
                <li>Not sure how to do it yourself or if it is even possible?</li>
              </ul>
              <h3>I will do it completely on contingency for the right clients.</h3>
              </div>
              <div class="cf hidden-xs">
                <div class="info-box">
                  <p>If you are accepted to my program,
                    <strong>you don’t have to pay</strong> me until your <span class="line">campaign makes you more money.</span></p>
                </div>
              
              <div class="img-graph">
                <img class="img-responsive" src="http://guaranteedppc.com/wp-content/uploads/2015/10/graph.png" alt="">
              </div>
            </div>
            
            <div class="optin-form">
                <?php echo do_shortcode('[contact-form-7 id="6212" title="LightboxForm" html_id="LightboxForm"]'); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

