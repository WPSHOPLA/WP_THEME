<?php

// Get Values from ACF 
$photo 			= get_field('photo');
$name 			= get_field('name');
$title 			= get_field('job_title');
$slogan 		= get_field('slogan');
$career1st 	= get_field('career_stats_first_text');
$career2nd 	= get_field('career_stats_second_text');
$hf_intro		= get_field('header_form_intro');
$hf_sIntro	= get_field('header_form_subintro');
$hf_desc		= get_field('header_form_description');
$hf_form		= get_field('header_form');

?>

<div id="about-me" class="front-header">
	<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<div class="corey-info">
					<div class="avatar-name clearfix">
						<img src="<?php echo $photo['url']; ?>" class="img-rounded avatar" alt="<?php echo $photo['alt']; ?>">
						<p class="name bitter-f"><?php echo $name; ?></p>
						<p class="title"><em><?php echo $title; ?></em></p>
					</div>
					<div class="corey-slogan">
						<i class="quote-icon spr"></i>
						<div><?php echo $slogan; ?></div>
					</div>
					<div class="career-stats">
						<h3 class="lobster-f"><i class="spr trophy-icon"></i> Career Stats</h3>
						<div class="row">
							<div class="col-xs-6 col-sm-12">
								<p><?php echo $career1st; ?> <i class="spr guage-bar"></i></p>
							</div>
							<div class="col-xs-6 col-sm-12">
								<p><?php echo $career2nd; ?> <i class="spr guage-bar"></i></p>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="col-sm-8">
				<div class="form-intro">
					<h1 class="bitter-f"><?php echo $hf_intro; ?></h1>
					<div class="sub-intro">
						<h2 class="bitter-f"><?php echo $hf_sIntro; ?></h2>
						<p><em><?php echo $hf_desc; ?></em></p>
					</div>
				</div>
			
				<div class="optin-form">
					<?php echo do_shortcode( $hf_form ); ?>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="logo-list">
	<div class="container">
		<?php
		// The Query
		$args = array(
			'post_type'				=> 'logos',
			'posts_per_page'	=> 4,
			'order'						=> 'ASC'
		);
		$the_query = new WP_Query( $args );

		// The Loop
		if ( $the_query->have_posts() ) {
			echo '<ul class="logos list-inline">';
			while ( $the_query->have_posts() ) {
				$the_query->the_post();

				$logo = get_the_post_thumbnail(get_the_id(), 'full', array('class' => 'img-responsive'));
				echo '<li>' . $logo . '</li>';
			}
			echo '</ul>';
		} else {
			// no posts found
		}
		/* Restore original Post Data */
		wp_reset_postdata();
		?>
	</div>
</div>
