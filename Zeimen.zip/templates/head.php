<!doctype html>

<html class="no-js" <?php language_attributes(); ?>>

<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title><?php wp_title('|', true, 'right'); ?></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">



  <link rel="alternate" type="application/rss+xml" title="<?php echo get_bloginfo('name'); ?> Feed" href="<?php echo esc_url(get_feed_link()); ?>">



  <?php wp_head(); ?>



<script src="//fast.wistia.net/labs/fresh-url/v1.js" async></script>

<script type="text/javascript" src="//cdn.callrail.com/companies/216886879/21b478797eb86e8accb7/12/swap.js"></script>

</head>