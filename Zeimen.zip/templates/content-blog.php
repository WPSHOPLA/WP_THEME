<article <?php post_class(); ?>>
  <header>
    <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>    
  </header>
  <div class="entry-summary">
    <?php the_excerpt(); ?>
  </div>
  <div class="post-meta">
  	<div class="leftAlign">
  		<a href="<?php the_permalink(); ?>" class="btn">Continue reading</a>
  		<script id="dsq-count-scr" src="//guaranteedppc.disqus.com/count.js" async></script>
  		<a href="<?php the_permalink(); ?>#disqus_thread" class="link-comments"></a>
  	</div>
  	<div class="socials">
      <div id="fb-root"></div><script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script><div class="fb-like" data-width="80" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>
  		<a class="twitter-share-button" href="https://twitter.com/share">Tweet</a><script>window.twttr=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.twttr||{};if(d.getElementById(id))return t;js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,"script","twitter-wjs"));</script>
      
  	</div>
  </div>
</article>
