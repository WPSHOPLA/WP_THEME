<div>
	<main class="main" role="main">
    	<div class="container wide-container">
        	<main class="page-content page-personal" role="main">
          		<section class="personal-top-section">
            		<div class="images-personal">
              			<br />
<b>Fatal error</b>:  Call to undefined function get_field() in <b>/home/guaranteedppc/public_html/wp-content/plugins/ppc-builder/admin/includes/Personal-page-template.php</b> on line <b>13</b><br />
