<?php

/*

Template Name: Service Menu Page Template

*/

?>

<div id="service_menu_page">
 <main class="main" role="main">
	<div id="smp_header">
         <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="container">
			<div class="smp-section-header">
				<h1><?php the_title(); ?></h1>
			</div>
		</div>
           <?php endwhile;?>
         <?php endif; ?>
 	</div>
	
	<div id="smp_content">
	 <?php if (have_posts()) : 
            while (have_posts()) : the_post();
            	the_content();
	    endwhile;
	 endif;?>

	</div>
 </main>
</div>