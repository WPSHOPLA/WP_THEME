<?php
/**
 * Utility functions
 */
function is_element_empty($element) {
  $element = trim($element);
  return !empty($element);
}

// Tell WordPress to use searchform.php from the templates/ directory
function roots_get_search_form() {
  $form = '';
  locate_template('/templates/searchform.php', true, false);
  return $form;
}
add_filter('get_search_form', 'roots_get_search_form');

/**
 * Add page slug to body_class() classes if it doesn't exist
 */
function roots_body_class($classes) {
  // Add post/page slug
  if (is_single() || is_page() && !is_front_page()) {
    if (!in_array(basename(get_permalink()), $classes)) {
      $classes[] = basename(get_permalink());
    }
  }
  return $classes;
}
add_filter('body_class', 'roots_body_class');

// Label Shortcode

function label_func( $atts, $content = null ) {
  extract(shortcode_atts(array(
    "text" => '',
  ), $atts));

  return '<span class="label label-warning">' . $text . '</span>';
}
add_shortcode( 'label', 'label_func' );

function my_acf_format_value( $value, $post_id, $field ) {
  
  // run do_shortcode on all textarea values
  $value = do_shortcode($value);
  
  
  // return
  return $value;
}
 
// filter for every value
// add_filter('acf/format_value', 'my_acf_format_value', 10, 3);
add_filter('acf/format_value/type=textarea', 'my_acf_format_value', 10, 3);

// ACF Pro 
// 1. customize ACF path
add_filter('acf/settings/path', 'my_acf_settings_path');
function my_acf_settings_path( $path ) {
  // update path
  $path = get_stylesheet_directory() . '/lib/acf/';
  // return
  return $path;
    
}

// 2. customize ACF dir
add_filter('acf/settings/dir', 'my_acf_settings_dir');
function my_acf_settings_dir( $dir ) {
  // update path
  $dir = get_stylesheet_directory_uri() . '/lib/acf/';
  // return
  return $dir;
}

// 3. Hide ACF field group menu item
add_filter('acf/settings/show_admin', '__return_false');

// 4. Include ACF
include_once( get_stylesheet_directory() . '/lib/acf/acf.php' );

// Load All Custom Fields
include_once( get_stylesheet_directory() . '/lib/custom-acf.php' );