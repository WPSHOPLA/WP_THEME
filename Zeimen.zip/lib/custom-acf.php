<?php

// server version

$aboutPage = 7885;

$bannersPage = 7906;

$landingPage = 9600;

// test for my localhost

//$landingPage = 7915;

// $aboutPage = 7847;

// $bannersPage = 7869;



if (function_exists('register_field_group')):



	register_field_group(array(

		'key' => 'group_548f94e960325',

		'title' => 'Front Page Builder',

		'fields' => array(

			array(

				'key' => 'field_548f939e1612b',

				'label' => 'About Me',

				'name' => '',

				'prefix' => '',

				'type' => 'tab',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

			),

			array(

				'key' => 'field_5490914967532',

				'label' => 'Photo',

				'name' => 'photo',

				'prefix' => '',

				'type' => 'image',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),

			array(

				'key' => 'field_548f93b2a6bd0',

				'label' => 'Name',

				'name' => 'name',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f93bba6bd1',

				'label' => 'Job Title',

				'name' => 'job_title',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f93c5a6bd2',

				'label' => 'Slogan',

				'name' => 'slogan',

				'prefix' => '',

				'type' => 'wysiwyg',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'tabs' => 'all',

				'toolbar' => 'basic',

				'media_upload' => 1,

			),

			array(

				'key' => 'field_548f93cfa6bd3',

				'label' => 'Career Stats First Text',

				'name' => 'career_stats_first_text',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 50,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f93e7a6bd4',

				'label' => 'Career Stats Second Text',

				'name' => 'career_stats_second_text',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 50,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9dedb2665',

				'label' => 'Header Form Intro',

				'name' => 'header_form_intro',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'wpautop',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9dfeb2666',

				'label' => 'Header Form Subintro',

				'name' => 'header_form_subintro',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'br',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9e1ab2667',

				'label' => 'Header Form Description',

				'name' => 'header_form_description',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'br',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9e2db2668',

				'label' => 'Header Form',

				'name' => 'header_form',

				'prefix' => '',

				'type' => 'text',

				'instructions' => 'Please add shortcode of Contact Form 7 here.',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9436733e9',

				'label' => 'How It Work',

				'name' => '',

				'prefix' => '',

				'type' => 'tab',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

			),

			array(

				'key' => 'field_548f944d733ea',

				'label' => 'Intro',

				'name' => 'hiw_intro',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'br',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f953039007',

				'label' => 'Feature List',

				'name' => 'hiw_feature_list',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'row',

				'button_label' => 'Add feature',

				'sub_fields' => array(

					array(

						'key' => 'field_548f954739008',

						'label' => 'Feature Item',

						'name' => 'feature_item',

						'prefix' => '',

						'type' => 'text',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),

			array(

				'key' => 'field_548f958deea3b',

				'label' => 'Headline Title',

				'name' => 'hiw_headline_title',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9a0f781c9',

				'label' => 'How It Work Row',

				'name' => 'how_it_work_row',

				'prefix' => '',

				'type' => 'flexible_content',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'button_label' => 'Add Row',

				'min' => '',

				'max' => '',

				'layouts' => array(

					array(

						'key' => '548f9a4c7b88e',

						'name' => 'two_column',

						'label' => 'Two Column',

						'display' => 'table',

						'sub_fields' => array(

							array(

								'key' => 'field_5490fe8e37481',

								'label' => 'Row Class',

								'name' => 'row_class',

								'prefix' => '',

								'type' => 'text',

								'instructions' => '',

								'required' => 0,

								'conditional_logic' => 0,

								'wrapper' => array(

									'width' => 20,

									'class' => '',

									'id' => '',

								),

								'default_value' => '',

								'placeholder' => '',

								'prepend' => '',

								'append' => '',

								'maxlength' => '',

								'readonly' => 0,

								'disabled' => 0,

							),

							array(

								'key' => 'field_548f9a63781cb',

								'label' => 'First Column',

								'name' => 'first_column',

								'prefix' => '',

								'type' => 'flexible_content',

								'instructions' => '',

								'required' => 0,

								'conditional_logic' => 0,

								'wrapper' => array(

									'width' => 40,

									'class' => '',

									'id' => '',

								),

								'button_label' => 'Add Item',

								'min' => '',

								'max' => '',

								'layouts' => array(

									array(

										'key' => '548f9a6c8982a',

										'name' => 'large_text',

										'label' => 'Large Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9a7c781cc',

												'label' => 'Large Text',

												'name' => 'large_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9a9c781cf',

										'name' => 'small_text',

										'label' => 'Small Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9aac781d0',

												'label' => 'Small Text',

												'name' => 'small_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9abc781d1',

										'name' => 'simple_image',

										'label' => 'Simple Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9aca781d2',

												'label' => 'Image',

												'name' => 'image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'preview_size' => 'thumbnail',

												'return_format' => 'array',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9ad4781d3',

										'name' => 'responsive_image',

										'label' => 'Responsive Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9ad9781d4',

												'label' => 'Desktop Image',

												'name' => 'desktop_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'preview_size' => 'thumbnail',

												'return_format' => 'array',

												'library' => 'all',

											),

											array(

												'key' => 'field_548f9ae5781d5',

												'label' => 'Mobile Image',

												'name' => 'mobile_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'preview_size' => 'thumbnail',

												'return_format' => 'array',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

								),

							),

							array(

								'key' => 'field_548f9b06781d6',

								'label' => 'Second Colum',

								'name' => 'second_column',

								'prefix' => '',

								'type' => 'flexible_content',

								'instructions' => '',

								'required' => 0,

								'conditional_logic' => 0,

								'wrapper' => array(

									'width' => 40,

									'class' => '',

									'id' => '',

								),

								'button_label' => 'Add Item',

								'min' => '',

								'max' => '',

								'layouts' => array(

									array(

										'key' => '548f9a6c8982a',

										'name' => 'large_text',

										'label' => 'Large Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9b07781d7',

												'label' => 'Large Text',

												'name' => 'large_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9a9c781cf',

										'name' => 'small_text',

										'label' => 'Small Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9b07781d8',

												'label' => 'Small Text',

												'name' => 'small_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9abc781d1',

										'name' => 'simple_image',

										'label' => 'Simple Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9b07781d9',

												'label' => 'Image',

												'name' => 'image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9ad4781d3',

										'name' => 'responsive_image',

										'label' => 'Responsive Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9b07781da',

												'label' => 'Desktop Image',

												'name' => 'desktop_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

											array(

												'key' => 'field_548f9b07781db',

												'label' => 'Mobile Image',

												'name' => 'mobile_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

								),

							),

						),

						'min' => 1,

						'max' => '',

					),

					array(

						'key' => '548f9b22781dd',

						'name' => 'one_column',

						'label' => 'One Column',

						'display' => 'table',

						'sub_fields' => array(

							array(

								'key' => 'field_5490fea837482',

								'label' => 'Row Class',

								'name' => 'row_class',

								'prefix' => '',

								'type' => 'text',

								'instructions' => '',

								'required' => 0,

								'conditional_logic' => 0,

								'wrapper' => array(

									'width' => 20,

									'class' => '',

									'id' => '',

								),

								'default_value' => '',

								'placeholder' => '',

								'prepend' => '',

								'append' => '',

								'maxlength' => '',

								'readonly' => 0,

								'disabled' => 0,

							),

							array(

								'key' => 'field_548f9b22781de',

								'label' => 'Column Item',

								'name' => 'column_item',

								'prefix' => '',

								'type' => 'flexible_content',

								'instructions' => '',

								'required' => 0,

								'conditional_logic' => 0,

								'wrapper' => array(

									'width' => 80,

									'class' => '',

									'id' => '',

								),

								'button_label' => 'Add Item',

								'min' => '',

								'max' => '',

								'layouts' => array(

									array(

										'key' => '548f9a6c8982a',

										'name' => 'large_text',

										'label' => 'Large Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9bbdde3d3',

												'label' => 'Large Text',

												'name' => 'large_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9a9c781cf',

										'name' => 'small_text',

										'label' => 'Small Text',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9bcbde3d4',

												'label' => 'Small Text',

												'name' => 'small_text',

												'prefix' => '',

												'type' => 'textarea',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'default_value' => '',

												'placeholder' => '',

												'maxlength' => '',

												'rows' => '',

												'new_lines' => 'br',

												'readonly' => 0,

												'disabled' => 0,

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9abc781d1',

										'name' => 'simple_image',

										'label' => 'Simple Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9bd5de3d5',

												'label' => 'Image',

												'name' => 'image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

									array(

										'key' => '548f9ad4781d3',

										'name' => 'responsive_image',

										'label' => 'Responsive Image',

										'display' => 'row',

										'sub_fields' => array(

											array(

												'key' => 'field_548f9bdfde3d6',

												'label' => 'Desktop Image',

												'name' => 'desktop_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

											array(

												'key' => 'field_548f9becde3d7',

												'label' => 'Mobile Image',

												'name' => 'mobile_image',

												'prefix' => '',

												'type' => 'image',

												'instructions' => '',

												'required' => 0,

												'conditional_logic' => 0,

												'wrapper' => array(

													'width' => '',

													'class' => '',

													'id' => '',

												),

												'return_format' => 'array',

												'preview_size' => 'thumbnail',

												'library' => 'all',

											),

										),

										'min' => '',

										'max' => '',

									),

								),

							),

						),

						'min' => 1,

						'max' => '',

					),

				),

			),

			array(

				'key' => 'field_548f9cbcc356e',

				'label' => 'Why Hire Me',

				'name' => '',

				'prefix' => '',

				'type' => 'tab',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

			),

			array(

				'key' => 'field_548f9cc7c356f',

				'label' => 'Headline Title',

				'name' => 'whm_headline_title',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9ceac3570',

				'label' => 'Text',

				'name' => 'whm_text',

				'prefix' => '',

				'type' => 'wysiwyg',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'tabs' => 'all',

				'toolbar' => 'basic',

				'media_upload' => 1,

			),

			array(

				'key' => 'field_548f9d37d4483',

				'label' => 'Bottom Form',

				'name' => '',

				'prefix' => '',

				'type' => 'tab',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

			),

			array(

				'key' => 'field_548f9d49d4484',

				'label' => 'Form Intro',

				'name' => 'bf_form_intro',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9d66d4486',

				'label' => 'Form Feature List',

				'name' => 'bf_feat_list',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'row',

				'button_label' => 'Add feature',

				'sub_fields' => array(

					array(

						'key' => 'field_548f9d66d4487',

						'label' => 'Feature Item',

						'name' => 'feature_item',

						'prefix' => '',

						'type' => 'text',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),

			array(

				'key' => 'field_548f9d9ad4488',

				'label' => 'Form Description',

				'name' => 'bf_form_description',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'br',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_548f9da7d4489',

				'label' => 'Form',

				'name' => 'bf_form',

				'prefix' => '',

				'type' => 'text',

				'instructions' => 'Please add shortcode of Contact Form 7 here.',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

		),

		'location' => array(

			array(

				array(

					'param' => 'post_type',

					'operator' => '==',

					'value' => 'page',

				),

				array(

					'param' => 'page',

					'operator' => '!=',

					'value' => $aboutPage,

				),

				array(

					'param' => 'page',

					'operator' => '!=',

					'value' => $bannersPage,

				),

				array(

					'param' => 'page',

					'operator' => '!=',

					'value' => $landingPage,

				)		

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'default',

		'label_placement' => 'top',

		'instruction_placement' => 'label',

		'hide_on_screen' => array(

			/*0 => 'the_content',

			1 => 'excerpt',

			2 => 'custom_fields',

			3 => 'discussion',

			4 => 'comments',

			5 => 'revisions',

			6 => 'author',

			7 => 'format',

			8 => 'featured_image',

			9 => 'categories',

			10 => 'tags',

			11 => 'send-trackbacks',*/

		),

	));



	register_field_group(array(

		'key' => 'group_54911c8baccd7',

		'title' => 'Testimonials info',

		'fields' => array(

			array(

				'key' => 'field_54911d1d06bb8',

				'label' => 'Testimonial',

				'name' => 'testimonial',

				'prefix' => '',

				'type' => 'textarea',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'maxlength' => '',

				'rows' => '',

				'new_lines' => 'br',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_54911d2c06bb9',

				'label' => 'Photo',

				'name' => 'photo',

				'prefix' => '',

				'type' => 'image',

				'instructions' => 'Please upload 60x60px photo',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 30,

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),

			array(

				'key' => 'field_54911d5206bba',

				'label' => 'Name',

				'name' => 'name',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 35,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'field_54911d5a06bbb',

				'label' => 'Company',

				'name' => 'company',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 35,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

		),

		'location' => array(

			array(

				array(

					'param' => 'post_type',

					'operator' => '==',

					'value' => 'cz_testimonials',

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'seamless',

		'label_placement' => 'top',

		'instruction_placement' => 'label',

		'hide_on_screen' => array(

			0 => 'permalink',

			1 => 'the_content',

			2 => 'excerpt',

			3 => 'custom_fields',

			4 => 'discussion',

			5 => 'comments',

			6 => 'revisions',

			7 => 'slug',

			8 => 'author',

			9 => 'format',

			10 => 'page_attributes',

			11 => 'featured_image',

			12 => 'categories',

			13 => 'tags',

			14 => 'send-trackbacks',

		),

	));



	register_field_group(array(

		'key' => 'group_54911c8bacc81',

		'title' => 'Post info',

		'fields' => array(

			array(

				'key' => 'field_53232c2ff3802',

				'label' => 'Difficulty',

				'name' => 'difficulty',

				'type' => 'select',

				'required' => 1,

				'choices' => array(

					'1' => '1',

					'2' => '2',

					'3' => '3',

					'4' => '4',

					'5' => '5',

					'6' => '6',

					'7' => '7',

					'8' => '8',

					'9' => '9',

					'10' => '10',

				),

				'default_value' => '7',

				'allow_null' => 0,

				'multiple' => 0,

			),

			array(

				'key' => 'field_54911d5206b81',

				'label' => 'Author',

				'name' => 'author',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 35,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'post_contact_label',

				'label' => 'Post Contact Label',

				'name' => 'post_contact_label',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'class' => '',

					'id' => '',

				),

				'default_value' => 'I&#039;ll improve your PPC campaign conversion in 60 days or <strong>I&#039;ll pay you $500</strong>',

				'placeholder' => 'I&#039;ll improve your PPC campaign conversion in 60 days or <strong>I&#039;ll pay you $500</strong>',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array (
				'key' => 'contact_label_size',

				'label' => 'Contact Label Size',

				'name' => 'contact_label_size',

				'type' => 'number',

				'required' => 0,

				'default_value' => '16',

				'placeholder' => '16',

				'prepend' => '',

				'append' => '%',

				'maxlength' => '3',

			),

			array (
				'key' => 'contact_label_color',
				'label' => 'Contact Label Font Color',
				'name' => 'contact_label_color',
				'type' => 'color_picker',
				'default_value' => '#000000',
			),

			array(

				'key' => 'post_contact_session_label',

				'label' => 'Post Contact Session Label',

				'name' => 'post_contact_session_label',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'class' => '',

					'id' => '',

				),

				'default_value' => 'Get Your Free Strategy Session Now',

				'placeholder' => 'Get Your Free Strategy Session Now',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'post_contact_submit_button',

				'label' => 'Post Contact Submit Button',

				'name' => 'post_contact_submit_button',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'class' => '',

					'id' => '',

				),

				'default_value' => 'Please, Help Me Fix My Broken Sales Funnel',

				'placeholder' => 'Please, Help Me Fix My Broken Sales Funnel',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array(

				'key' => 'post_contact_waiting',

				'label' => 'Post Contact waiting Notes',

				'name' => 'post_contact_waiting',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'class' => '',

					'id' => '',

				),

				'default_value' => 'After you fill out the above form, I will contact you within 24 hours to discuss your business objectives.',

				'placeholder' => 'After you fill out the above form, I will contact you within 24 hours to discuss your business objectives.',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),



		),

		'location' => array(

			array(

				array(

					'param' => 'post_type',

					'operator' => '==',

					'value' => 'post',

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'seamless',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));













	register_field_group(array(

		'key' => 'group_acf_employee',

		'title' => 'employee info',

		'fields' => array(			

			array(

				'key' => 'field_acf_employee',

				'label' => 'Role',

				'name' => 'role',

				'prefix' => '',

				'type' => 'text',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => 35,

					'class' => '',

					'id' => '',

				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			)



		),

		'location' => array(

			array(

				array(

					'param' => 'post_type',

					'operator' => '==',

					'value' => 'employee',

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'seamless',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));


		register_field_group(array(

		'key' => 'group_acf_caseStudy',
		'title' => 'Case Study Info',
		'fields' => array(		

			array (

				'key' => 'field_acf_CaseType',
				'label' => 'Case Type',
				'name' => 'CaseType',
				'prefix' => '',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => 35,
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),

			array (

				'key' => 'field_acf_CaseTypeSubtitle',
				'label' => 'Case Type Subtitle',
				'name' => 'CaseTypeSubtitle',
				'prefix' => '',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => 35,
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),

			array (

				'key' => 'field_acf_NumberOfConversions',
				'label' => 'Number of Conversions',
				'name' => 'NumberOfConversions',
				'prefix' => '',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => 35,
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),

			array (

				'key' => 'field_acf_CostOfConversions',
				'label' => 'Cost of Conversions Improvement',
				'name' => 'CostOfConversions',
				'prefix' => '',
				'type' => 'text',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => 35,
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			),

			array (

				'key' => 'field_acf_caseShortText',
				'label' => 'Case Study Short Text',
				'name' => 'caseShortText',
				'prefix' => '',
				'type' => 'textarea',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => 100,
					'class' => '',
					'id' => '',
				),
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'maxlength' => '',
				'readonly' => 0,
				'disabled' => 0,
			)
			// array(

			// 	'key' => 'field_548f',

			// 	'label' => 'Page blocks',

			// 	'name' => 'bf_feat_list',

			// 	'prefix' => '',

			// 	'type' => 'repeater',

			// 	'instructions' => '',

			// 	'required' => 0,

			// 	'conditional_logic' => 0,

			// 	'wrapper' => array(

			// 		'width' => '',

			// 		'class' => '',

			// 		'id' => '',

			// 	),

			// 	'min' => '',

			// 	'max' => '',

			// 	'layout' => 'row',

			// 	'button_label' => 'Add text block',

			// 	'sub_fields' => array(

			// 		array(
			// 			'key' => 'field_548',
			// 			'label' => 'Text block title',
			// 			'name' => 'case_text_block',
			// 			'prefix' => '',
			// 			'type' => 'wysiwyg',
			// 			'instructions' => '',
			// 			'required' => 0,
			// 			'conditional_logic' => 0,
			// 			'wrapper' => array(
			// 				'width' => '',
			// 				'class' => '',
			// 				'id' => '',
			// 			),
			// 			'default_value' => '',
			// 			'placeholder' => '',
			// 			'prepend' => '',
			// 			'append' => '',
			// 			'maxlength' => '',
			// 			'readonly' => 0,
			// 			'disabled' => 0,

			// 		),

			// 	),

			// )

		),

		'location' => array(
			array(
				array(
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'casestudy',
				),
			),
		),

		'menu_order' => 0,
		'position' => 'acf_after_title',
		'style' => 'seamless',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
	));







	register_field_group(array(

		'key' => 'group_acf_about',

		'title' => 'Top images',

		'fields' => array(		

			array(

				'key' => 'about_photo_main',

				'label' => 'about photo main (288*318)',

				'name' => 'about_photo_main',

				'prefix' => '',

				'type' => 'image',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),	

			array(

				'key' => 'about_1',

				'label' => 'about photo 1 (140*99)',

				'name' => 'about_photo_1',

				'prefix' => '',

				'type' => 'image',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),

			array(

				'key' => 'about_2',

				'label' => 'about photo 2 (140*99)',

				'name' => 'about_photo_2',

				'prefix' => '',

				'type' => 'image',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),

			array(

				'key' => 'about_3',

				'label' => 'about photo 3 (140*99)',

				'name' => 'about_photo_3',

				'prefix' => '',

				'type' => 'image',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'return_format' => 'array',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			)



		),

		'location' => array(

			array(

				array(

					'param' => 'page',

					'operator' => '==',

					'value' => $aboutPage,

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'default',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));



	register_field_group(array(

		'key' => 'group_acf_banners',

		'title' => 'banners',

		'fields' => array(

		array(

				'key' => 'banners_group',

				'label' => 'Banners top group',

				'name' => 'banners_group',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'row',

				'button_label' => 'Add banners',

				'sub_fields' => array(

					array(

						'key' => 'banner_300_600',

						'label' => 'Banner 300*600',

						'name' => 'banners_300_600',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_160_600',

						'label' => 'Banner 160*600',

						'name' => 'banners_160_600',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_728_90',

						'label' => 'Banner 728*90',

						'name' => 'banners_728_90',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_336_280',

						'label' => 'Banner 336*280',

						'name' => 'banners_336_280',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_300_250',

						'label' => 'Banner 300*250',

						'name' => 'banners_300_250',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_200_200',

						'label' => 'Banner 200*200',

						'name' => 'banners_200_200',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'banner_250_250',

						'label' => 'Banner 250*250',

						'name' => 'banners_250_250',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),



			array(

				'key' => 'banners_300_group',

				'label' => 'Banners 300*250',

				'name' => 'banners_300_group',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'horizontal',

				'button_label' => 'Add banner 300*250',

				'sub_fields' => array(

					array(

						'key' => 'banners_300_250',

						'label' => 'Banner',

						'name' => 'banners_300_250',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),

			array(

				'key' => 'banners_160_group',

				'label' => 'Banners 160*600',

				'name' => 'banners_160_group',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'horizontal',

				'button_label' => 'Add banner 160*600',

				'sub_fields' => array(

					array(

						'key' => 'banners_160_600',

						'label' => 'Banner',

						'name' => 'banners_160_600',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),

			array(

				'key' => 'banners_728_group',

				'label' => 'Banners 728*90',

				'name' => 'banners_728_group',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'horizontal',

				'button_label' => 'Add banner 728*90',

				'sub_fields' => array(

					array(

						'key' => 'banners_728_90',

						'label' => 'Banner',

						'name' => 'banners_728_90',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			)

		)

		,

		'location' => array(

			array(

				array(

					'param' => 'page',

					'operator' => '==',

					'value' => $bannersPage,

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'default',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));



	register_field_group(array(

		'key' => 'group_acf_ladings',

		'title' => 'banners',

		'fields' => array(

		array(

				'key' => 'landings_group',

				'label' => 'Landings pages',

				'name' => 'ladings_group',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'row',

				'button_label' => 'Add image',

				'sub_fields' => array (

					

					array(

						'key' => 'landing_image',

						'label' => 'Landing Image',

						'name' => 'landing_image',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					array(

						'key' => 'landing_image_modal',

						'label' => 'Landing Image Big',

						'name' => 'landing_image_modal',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

					

				)

			)

		)

		,

		'location' => array(

			array(

				array(

					'param' => 'page',

					'operator' => '==',

					'value' => $landingPage,

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'default',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));





	register_field_group(array(

		'key' => 'client_logos_group',

		'title' => 'Client Logos',

		'fields' => array(



			array(

				'key' => 'client_logos',

				'label' => 'Client logos',

				'name' => 'client_logos',

				'prefix' => '',

				'type' => 'repeater',

				'instructions' => '',

				'required' => 0,

				'conditional_logic' => 0,

				'wrapper' => array(

					'width' => '',

					'class' => '',

					'id' => '',

				),

				'min' => '',

				'max' => '',

				'layout' => 'horizontal',

				'button_label' => 'Add image',

				'sub_fields' => array(

					array(

						'key' => 'client_logo',

						'label' => 'Logo',

						'name' => 'client_logo',

						'prefix' => '',

						'type' => 'image',

						'instructions' => '',

						'required' => 0,

						'conditional_logic' => 0,

						'wrapper' => array(

							'width' => '',

							'class' => '',

							'id' => '',

						),

						'default_value' => '',

						'placeholder' => '',

						'prepend' => '',

						'append' => '',

						'maxlength' => '',

						'readonly' => 0,

						'disabled' => 0,

					),

				),

			),

		)

		,

		'location' => array(

			array(

				array(

					'param' => 'page',

					'operator' => '==',

					'value' => $aboutPage,

				),

			),

		),

		'menu_order' => 0,

		'position' => 'acf_after_title',

		'style' => 'default',

		'label_placement' => 'top',

		'instruction_placement' => 'label',



	));





	register_field_group(array (

		'id' => 'acf_personal-page-fields',

		'title' => 'Personal Page Fields',

		'fields' => array (

			array (

				'key' => 'field_57587ef5405f3',

				'label' => 'Personal Logo',

				'name' => 'personal_logo',

				'type' => 'image',

				'required' => 1,

				'save_format' => 'url',

				'preview_size' => 'thumbnail',

				'library' => 'all',

			),

			array (
				'key' => 'personal_bt_before_value',

				'label' => 'Personal Before Button Value',

				'name' => 'personal_bt_before_value',

				'type' => 'number',

				'required' => 1,

				'default_value' => '40',

				'placeholder' => '40',

				'prepend' => '',

				'append' => '%',

				'maxlength' => '3',

			),

			array (
				'key' => 'personal_bt_before_title',

				'label' => 'Personal Before Button Title',

				'name' => 'personal_bt_before_title',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Costs Per Lead Before',

				'placeholder' => 'Costs Per Lead Before',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (
				'key' => 'personal_bt_after_value',

				'label' => 'Personal After Button Value',

				'name' => 'personal_bt_after_value',

				'type' => 'number',

				'required' => 1,

				'default_value' => '-20',

				'placeholder' => '-20',

				'prepend' => '',

				'append' => '%',

				'maxlength' => '3',

			),

			array (
				'key' => 'personal_bt_after_title',

				'label' => 'Personal After Button Title',

				'name' => 'personal_bt_after_title',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Costs Per Lead After',

				'placeholder' => 'Costs Per Lead After',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (
				'key' => 'personal_ad_title',

				'label' => 'Personal Ad Title',

				'name' => 'personal_ad_title',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Who&rsquo;s Getting All Your Money?',

				'placeholder' => 'Who&rsquo;s Getting All Your Money?',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),
			
			array (
				'key' => 'personal_ad_img',

				'label' => 'Personal Ad Image',

				'name' => 'personal_ad_img',

				'type' => 'image',

				'prefix' => '',

				'instructions' => '',

				'required' => 1,

				'conditional_logic' => 0,

				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),

				'default_value' => '',

				'placeholder' => '',

				'prepend' => '',

				'append' => '',

				'maxlength' => '',

				'readonly' => 0,

				'disabled' => 0,

			),

			array (

				'key' => 'field_57587f68405f4',

				'label' => 'Personal Content Title',

				'name' => 'personal_content_title',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Andrew Goldstein...',

				'placeholder' => 'Andrew Goldstein...',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (

				'key' => 'field_57587fd9405f5',

				'label' => 'Personal P-1',

				'name' => 'personal_p-1',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Learn more about my guarantee to increase your sales and make you money.',

				'placeholder' => 'Learn more about my guarantee to increase your sales and make you money.',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (

				'key' => 'field_57588088405f8',

				'label' => 'Personal Help Button',

				'name' => 'personal_help_button',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Help Me Increase My Sales',

				'placeholder' => 'Help Me Increase My Sales',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (

				'key' => 'field_575887ba6f2d4',

				'label' => 'Personal Help button Link',

				'name' => 'personal_help_button_link',

				'type' => 'page_link',

				'post_type' => array (

					0 => 'all',

				),

				'allow_null' => 1,

				'multiple' => 0,

			),

			array (

				'key' => 'field_57588023405f6',

				'label' => 'Personal P-2',

				'name' => 'personal_p-2',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'Case Studies that demonstrates my ability to deliver results.',

				'placeholder' => 'Case Studies that demonstrates my ability to deliver results.',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (

				'key' => 'field_575880c5405f9',

				'label' => 'Personal See Button',

				'name' => 'personal_see_button',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'See Proof',

				'placeholder' => 'See Proof',

				'prepend' => '',

				'append' => '',

				'formatting' => 'html',

				'maxlength' => '',

			),

			array (

				'key' => 'field_575887e46f2d5',

				'label' => 'Personal See button Link',

				'name' => 'personal_see_button_link',

				'type' => 'page_link',

				'post_type' => array (

					0 => 'all',

				),

				'allow_null' => 1,

				'multiple' => 0,

			),

			array (

				'key' => 'field_575880ee405fa',

				'label' => 'Personal Youtube URL',

				'name' => 'personal_youtube_url',

				'type' => 'text',

				'required' => 1,

				'default_value' => 'https://www.youtube.com/embed/865cPTIgaIg',

				'placeholder' => 'https://www.youtube.com/embed/865cPTIgaIg',

				'prepend' => '',

				'append' => '',

				'formatting' => 'none',

				'maxlength' => '',

			),

		),

		'location' => array (

			array (

				array (

					'param' => 'page_template',

					'operator' => '==',

					'value' => 'page-personal.php',

					'order_no' => 0,

					'group_no' => 0,

				),

			),

		),

		'options' => array (

			'position' => 'normal',

			'layout' => 'no_box',

			'hide_on_screen' => array (

				0 => 'the_content',

				1 => 'discussion',

				2 => 'comments',

				3 => 'slug',

				4 => 'author',

				5 => 'featured_image',

				6 => 'categories',

				7 => 'tags',

				8 => 'send-trackbacks',

			),

		),

		'menu_order' => 0,

	));





endif;