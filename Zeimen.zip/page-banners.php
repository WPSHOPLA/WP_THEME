<?php
/*
Template Name: Banners Page Template
*/
?>
<div>
	<main class="main" role="main">
		<div class="container wide-container">
        <main class="page-content page-banners" role="main">
          <h1 class="page-title">Banner Ad Examples</h1>
          <hr>

          <?php
          if( have_rows('banners_group') ):
            echo '<div class="banners-section cf"> ';
             while ( have_rows('banners_group') ) : the_row();
                echo '<div class="col-left  hidden-xs">';

                $img = get_sub_field('banners_300_600',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';
                $img = get_sub_field('banner_160_600',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';

                echo '</div><div class="col-right">';

                $img = get_sub_field('banner_728_90',$post->ID);
                echo '<span class="item no-padding-right"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';

                echo '<div class="cf step-2">';

                $img = get_sub_field('banner_336_280',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';
                $img = get_sub_field('banner_300_250',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';

                echo '</div><div class="cf step-3">';

                $img = get_sub_field('banner_200_200',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';
                $img = get_sub_field('banner_250_250',$post->ID);
                echo '<span class="item"><img class="img-responsive" src="'.$img['url'].'" alt="" ></span>';

                echo '</div></div>';

            endwhile;
            echo '</div> <hr>';
          endif;
           ?>  
          <?php
          if( have_rows('banners_300_group') ):
            echo '<div class="banners-300"><ul class="banner-list-300 isotope-grid">';
             while ( have_rows('banners_300_group') ) : the_row();
                
                $img = get_sub_field('banners_300_250',$post->ID);
                echo '<li><img class="img-responsive" src="'.$img['url'].'" alt="" ></li>';

            endwhile;
            echo '</ul></div>';
          endif;
           ?>         

          <hr>

          <?php
          if( have_rows('banners_160_group') ):
            echo '<div class="banners-vertical"><ul class="banner-list-vertical">';
             while ( have_rows('banners_160_group') ) : the_row();
                
                $img = get_sub_field('banners_160_600',$post->ID);
                echo '<li><img class="img-responsive" src="'.$img['url'].'" alt="" ></li>';

            endwhile;
            echo '</ul></div>';
          endif;
           ?> 

          <hr>

          <?php
          if( have_rows('banners_728_group') ):
            echo '<div class="banners-horizontal"><ul class="banner-list-horizontal">';
             while ( have_rows('banners_728_group') ) : the_row();
                
                $img = get_sub_field('banners_728_90',$post->ID);
                echo '<li><img class="img-responsive" src="'.$img['url'].'" alt="" ></li>';

            endwhile;
            echo '</ul></div>';
          endif;
           ?> 
          

        </main>
        
      </div>
	</main>

</div>